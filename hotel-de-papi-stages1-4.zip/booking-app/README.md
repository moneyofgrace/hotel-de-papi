# Hotel De' Papi — Booking & Nightlife Platform

A full-stack booking site for Hotel De' Papi (Ughelli North, Delta State): a
hotel/short-let apartment business with an attached nightlife club. This
covers **Stages 1–4: foundation, rooms listing, room details, and the
booking flow**.

## Stack

- **Next.js 14 (App Router) + TypeScript** — one codebase serves both the
  customer site and the admin dashboard, with API routes doing backend work.
  No separate backend server to deploy or keep in sync.
- **Tailwind CSS** — utility-first styling, fast to keep consistent across a
  large multi-page app (homepage, room pages, club pages, admin screens).
- **Prisma + PostgreSQL** (SQLite locally) — a real relational database.
  Schema is already sketched in `prisma/schema.prisma` (rooms, bookings,
  customers, club events, VIP tables, admins) as the plan for Stage 7.
- **NextAuth.js** (Stage 8) — secure session-based login for the admin
  dashboard, separate from customer accounts.
- **Paystack** (Stage 10) — Nigerian card, bank transfer, and USSD payments.
  The `Booking` and `TableReservation` models already have `paystackRef`
  and `paymentStatus` fields reserved for this.
- **Cloudinary or S3-compatible storage** (Stage 9) — for admin-uploaded
  room and event photos, rather than storing images in the database.

Why this stack: it is the fastest path to a real, deployable full-stack app
(not a static site) while staying inside a single, well-documented framework.
Next.js deploys cleanly to Vercel; Prisma/Postgres can run on Neon, Supabase,
or Railway — all of which have free tiers suitable for a small Nigerian
business, and all support scaling up later.

## What's built so far

**Stage 1 — Foundation + homepage**
- Project scaffolding: Next.js, TypeScript, Tailwind, Prisma config.
- `prisma/schema.prisma` — the full planned data model (not yet connected;
  every page still reads from `src/lib/data/rooms.ts` mock data).
- Homepage: hero with a working search bar, room grid, nightlife teaser
  band, footer with the real address and Google Maps embed, floating
  WhatsApp/call button.
- Brand palette sampled directly from your logo — deep bottle green
  (`ink`, `#1A3234`) and copper/peach gold (`gold-bright`, `#DD9970`) on a
  warm ivory background (`sand`).
- Real photography: your logo in the navbar, your actual courtyard shot as
  the hero background, and two room cards using your real interior photos
  (`public/brand/`).

**Stage 2 — Rooms & apartments listing (`/rooms`)**
- Every room, filterable by type (Standard / Deluxe / Suite / Apartment).
- Listing cards show photo, availability badge, type, short description,
  price/night, guest/bed/bath counts, amenities, "View details" and
  "Book now".
- Landing here from the homepage search bar carries guest count through as
  a real filter; dates are shown back to the customer but not yet checked
  against a calendar (that needs Stage 7's database).

**Stage 3 — Individual room page (`/rooms/[slug]`)**
- Gallery, full description, amenities, house rules, check-in/out times.

**Stage 4 — Booking flow**
- A real booking form on the room page: dates, guest count (capped to the
  room's max), guest name and phone, live night/price calculation, and
  validation (no booking without valid dates, no exceeding room capacity).
- Submitting takes you to `/booking/confirmation` with a generated
  reference (`HDP-2026-000123` style), full price breakdown, and a
  "Confirm via WhatsApp" button that opens a pre-filled message to the
  hotel's real WhatsApp number.

**Important honesty note on Stages 2–4:** none of this is backed by a
database yet, so two things are not real: (1) nothing is actually saved —
refresh the confirmation page's URL and it still "works" only because the
booking details are sitting in the URL, not in storage; (2) no date is
ever rejected for being already booked, because there's no calendar to
check against yet. Both become real in Stage 7. Until then, treat every
booking as a request the front desk still needs to call and confirm — the
confirmation page says exactly that, rather than pretending it's final.

**About the two interior photos:** both came from a video with on-screen
text baked into the footage. I blurred a small handwritten caption out of
one, and blurred a table branded with a Gucci logo out of the other —
featuring another brand's trademark on Hotel De' Papi's own marketing
photos could read as an unauthorized endorsement, so it's safer left out.
The blur is a quick fix, not a proper retouch — for a permanent version,
re-shoot those two spots or send me the same photos without that overlay
and branding and I'll swap them in cleanly. Rooms 3 and 4 still use stock
photography pending more real photos from you.

## Running locally

```bash
npm install
cp .env.example .env
npm run dev
```

Open http://localhost:3000.

## Roadmap

1. **Foundation + homepage** ✅
2. **Rooms & apartments listing** (`/rooms`, filterable) ✅
3. **Individual room page** (gallery, description, house rules) ✅
4. **Booking flow** (dates, guests, price calc, confirmation page) ✅
5. **Restaurant & food ordering** — menu categories, cart, checkout, and a
   room-service flow (guest name, phone, room number, instructions).
6. **Club, VIP tables & events** — expand today's teaser into a real page:
   event listing, table packages, and a reservation flow like the room
   booking one.
7. **Database** — Prisma connected to real Postgres, replacing all mock
   data, adding `FoodItem`/`Order`/`VIPReservation`/`Event` models, and
   making booking dates actually check against real availability.
8. **Authentication** — secure admin login (NextAuth.js), route protection
   for `/admin`.
9. **Admin dashboard** — overview stats, rooms/menu/events management,
   order and booking status updates. *(Saved for after 5–8 so there's a
   real system underneath it to manage, per your instruction to finish the
   other stages first.)*
10. **Paystack** — checkout on room bookings, food orders, and VIP/event
    reservations; payment status states (pending/paid/failed/refunded);
    secret keys stay server-side only.
11. **Testing + deployment prep** — full flow QA, environment variables,
    deploy to Vercel + hosted Postgres.

WhatsApp and Google Maps are already wired to the real number and address
from Stage 1 onward, and get extended with more message types (order
confirmations, VIP reservations) as Stages 5–6 add them.

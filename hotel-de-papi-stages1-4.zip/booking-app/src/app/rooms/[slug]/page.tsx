import { notFound } from "next/navigation";
import Image from "next/image";
import { BedDouble, Bath, Users, Check } from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import FloatingContact from "@/components/layout/FloatingContact";
import BookingForm from "@/components/rooms/BookingForm";
import { rooms, getRoomBySlug } from "@/lib/data/rooms";
import { formatNaira } from "@/lib/booking";

export function generateStaticParams() {
  return rooms.map((room) => ({ slug: room.slug }));
}

export default function RoomDetailsPage({
  params,
}: {
  params: { slug: string };
}) {
  const room = getRoomBySlug(params.slug);
  if (!room) notFound();

  return (
    <main className="min-h-screen bg-sand">
      <div className="relative">
        <Navbar />
        <div className="relative h-[46vh] min-h-[340px] w-full overflow-hidden">
          <Image src={room.image} alt={room.name} fill className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-ink/40" />
        </div>
      </div>

      <div className="mx-auto max-w-content px-6 py-10 md:px-10">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <span className="text-xs font-medium uppercase tracking-wide text-gold">
              {room.type}
            </span>
            <h1 className="mt-1 font-display text-3xl text-ink md:text-4xl">
              {room.name}
            </h1>
            <p className="mt-1 text-sm text-ink/60">{room.location}</p>

            <div className="mt-4 flex items-center gap-5 text-ink/70">
              <span className="flex items-center gap-1.5 text-sm">
                <Users size={16} /> {room.maxGuests} guests
              </span>
              <span className="flex items-center gap-1.5 text-sm">
                <BedDouble size={16} /> {room.bedInfo}
              </span>
              <span className="flex items-center gap-1.5 text-sm">
                <Bath size={16} /> {room.bathrooms} bath
                {room.bathrooms > 1 ? "s" : ""}
              </span>
            </div>

            {room.gallery.length > 1 && (
              <div className="mt-6 grid grid-cols-3 gap-3">
                {room.gallery.map((src, i) => (
                  <div
                    key={i}
                    className="relative aspect-square overflow-hidden rounded-xl"
                  >
                    <Image
                      src={src}
                      alt={`${room.name} photo ${i + 1}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>
            )}

            <div className="mt-8">
              <h2 className="font-display text-xl text-ink">About this room</h2>
              <p className="mt-2 text-ink/70">{room.description}</p>
            </div>

            <div className="mt-8">
              <h2 className="font-display text-xl text-ink">Amenities</h2>
              <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                {room.amenities.map((item) => (
                  <span
                    key={item}
                    className="flex items-center gap-2 text-sm text-ink/70"
                  >
                    <Check size={14} className="text-gold" /> {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-8">
              <h2 className="font-display text-xl text-ink">House rules</h2>
              <ul className="mt-3 flex flex-col gap-1.5 text-sm text-ink/70">
                {room.houseRules.map((rule) => (
                  <li key={rule}>· {rule}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="lg:sticky lg:top-24">
              <p className="mb-4 text-sm font-medium text-ink/60">
                {formatNaira(room.pricePerNight)} / night ·{" "}
                {room.available ? (
                  <span className="text-ink">Available now</span>
                ) : (
                  <span className="text-ink/50">Fully booked</span>
                )}
              </p>
              <BookingForm room={room} />
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <FloatingContact />
    </main>
  );
}

"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import FloatingContact from "@/components/layout/FloatingContact";
import RoomTypeFilter from "@/components/rooms/RoomTypeFilter";
import RoomListingCard from "@/components/rooms/RoomListingCard";
import { rooms } from "@/lib/data/rooms";
import { RoomType } from "@/types";

export default function RoomsPage() {
  const searchParams = useSearchParams();
  const checkIn = searchParams.get("checkIn");
  const checkOut = searchParams.get("checkOut");
  const guestsParam = searchParams.get("guests");
  const requestedGuests = guestsParam ? Number(guestsParam) : null;

  const [activeType, setActiveType] = useState<RoomType | "All">("All");

  const filteredRooms = useMemo(() => {
    return rooms.filter((room) => {
      const matchesType = activeType === "All" || room.type === activeType;
      const matchesGuests = !requestedGuests || room.maxGuests >= requestedGuests;
      return matchesType && matchesGuests;
    });
  }, [activeType, requestedGuests]);

  const hasSearch = checkIn || checkOut || requestedGuests;

  return (
    <main className="min-h-screen bg-sand">
      <div className="relative bg-ink px-6 pb-16 pt-32 md:px-10 md:pt-40">
        <Navbar />
        <div className="mx-auto max-w-content">
          <p className="mb-3 text-sm font-medium uppercase tracking-[0.2em] text-gold-bright">
            Hotel De&apos; Papi
          </p>
          <h1 className="max-w-xl font-display text-3xl text-sand md:text-5xl">
            Rooms &amp; apartments
          </h1>
          <p className="mt-4 max-w-lg text-sand/70">
            From a single night to an extended stay — every room includes
            24-hour front desk service and Wi-Fi.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-content px-6 py-12 md:px-10">
        {hasSearch && (
          <div className="mb-6 rounded-xl bg-white/50 px-4 py-3 text-sm text-ink/70">
            Showing rooms
            {requestedGuests ? ` for ${requestedGuests} guests` : ""}
            {checkIn ? `, check-in ${checkIn}` : ""}
            {checkOut ? `, check-out ${checkOut}` : ""}. Dates aren&apos;t
            checked against a live calendar yet — confirm exact availability
            with the front desk or on the room&apos;s booking form.
          </div>
        )}

        <div className="mb-8">
          <RoomTypeFilter active={activeType} onChange={setActiveType} />
        </div>

        {filteredRooms.length === 0 ? (
          <p className="py-16 text-center text-ink/60">
            No rooms match that search — try a different type or guest count.
          </p>
        ) : (
          <div className="flex flex-col gap-8">
            {filteredRooms.map((room) => (
              <RoomListingCard key={room.id} room={room} />
            ))}
          </div>
        )}
      </div>

      <Footer />
      <FloatingContact />
    </main>
  );
}

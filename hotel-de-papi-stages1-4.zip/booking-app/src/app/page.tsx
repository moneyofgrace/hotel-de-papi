import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import FloatingContact from "@/components/layout/FloatingContact";
import Hero from "@/components/home/Hero";
import RoomsGrid from "@/components/home/RoomsGrid";
import ClubTeaser from "@/components/home/ClubTeaser";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-sand">
      <Navbar />
      <Hero />
      <RoomsGrid />
      <ClubTeaser />
      <Footer />
      <FloatingContact />
    </main>
  );
}

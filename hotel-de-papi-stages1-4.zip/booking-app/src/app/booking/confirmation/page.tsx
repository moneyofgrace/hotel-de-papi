import Link from "next/link";
import { CheckCircle2, MessageCircle } from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { formatNaira } from "@/lib/booking";

const WHATSAPP_NUMBER = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "2348151123462";

export default function BookingConfirmationPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | undefined };
}) {
  const {
    ref,
    type,
    room,
    checkIn,
    checkOut,
    nights,
    guests,
    total,
    name,
    phone,
  } = searchParams;

  // If someone lands here without going through the booking form, there's
  // nothing real to confirm — send them back to browse rooms instead of
  // showing a fake success page.
  if (!ref || !room || !total) {
    return (
      <main className="flex min-h-screen flex-col bg-sand">
        <div className="relative bg-ink pb-10 pt-32 md:pt-40">
          <Navbar />
        </div>
        <div className="mx-auto flex max-w-content flex-1 flex-col items-center justify-center px-6 py-20 text-center">
          <h1 className="font-display text-2xl text-ink">
            No booking to confirm
          </h1>
          <p className="mt-2 max-w-sm text-ink/60">
            This page only shows a confirmation right after you book a room.
          </p>
          <Link
            href="/rooms"
            className="mt-6 rounded-full bg-gold-bright px-6 py-3 text-sm font-semibold text-ink"
          >
            Browse rooms
          </Link>
        </div>
        <Footer />
      </main>
    );
  }

  const whatsappMessage = encodeURIComponent(
    `Hi Hotel De' Papi, I'd like to confirm my booking.\n\n` +
      `Reference: ${ref}\n` +
      `Type: ${type ?? "Room booking"}\n` +
      `Room: ${room}\n` +
      `Check-in: ${checkIn}\n` +
      `Check-out: ${checkOut}\n` +
      `Guests: ${guests}\n` +
      `Total: ${formatNaira(Number(total))}\n` +
      `Name: ${name}\n` +
      `Phone: ${phone}`
  );

  return (
    <main className="flex min-h-screen flex-col bg-sand">
      <div className="relative bg-ink pb-10 pt-32 md:pt-40">
        <Navbar />
      </div>

      <div className="mx-auto w-full max-w-xl flex-1 px-6 py-14 md:px-0">
        <div className="rounded-2xl bg-white/50 p-6 md:p-8">
          <CheckCircle2 className="text-gold" size={40} />
          <h1 className="mt-4 font-display text-2xl text-ink md:text-3xl">
            Booking request received
          </h1>
          <p className="mt-2 text-sm text-ink/60">
            Reference <span className="font-medium text-ink">{ref}</span>.
            Our front desk will call {phone} to confirm — this isn&apos;t
            checked against a live calendar yet, so hold off on travel plans
            until you hear back.
          </p>

          <div className="mt-6 flex flex-col gap-3 border-t border-ink/10 pt-6 text-sm">
            <Row label="Room" value={room} />
            <Row label="Guest name" value={name} />
            <Row label="Phone" value={phone} />
            <Row label="Check-in" value={checkIn} />
            <Row label="Check-out" value={checkOut} />
            <Row label="Nights" value={nights} />
            <Row label="Guests" value={guests} />
            <Row label="Status" value="Pending confirmation" />
          </div>

          <div className="mt-4 flex items-center justify-between border-t border-ink/10 pt-4">
            <span className="text-sm font-medium text-ink/60">Total</span>
            <span className="font-display text-2xl text-ink">
              {formatNaira(Number(total))}
            </span>
          </div>

          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappMessage}`}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 flex items-center justify-center gap-2 rounded-full bg-gold px-6 py-3.5 text-sm font-semibold text-sand transition hover:bg-gold-bright hover:text-ink"
          >
            <MessageCircle size={18} />
            Confirm via WhatsApp
          </a>

          <Link
            href="/rooms"
            className="mt-3 flex items-center justify-center rounded-full border border-ink/15 px-6 py-3 text-sm font-medium text-ink/70 hover:border-ink/40"
          >
            Back to rooms
          </Link>
        </div>
      </div>

      <Footer />
    </main>
  );
}

function Row({ label, value }: { label: string; value?: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-ink/50">{label}</span>
      <span className="font-medium text-ink">{value}</span>
    </div>
  );
}

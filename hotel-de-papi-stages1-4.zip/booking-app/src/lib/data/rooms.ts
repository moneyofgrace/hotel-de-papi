import { Room } from "@/types";

// Placeholder data. In the database stage, this will be replaced by
// `prisma.room.findMany()` calls against the Room model in schema.prisma.
//
// Photography note: rooms 1 and 2 use real Hotel De' Papi photography
// (public/brand), lightly retouched — a small handwritten caption was
// blurred out of room 1, and a branded (Gucci-logo) table was blurred out
// of room 2 to avoid implying a trademark endorsement on the live site.
// Rooms 3 and 4 are still stock photography pending real photos of those
// rooms. Availability is placeholder (`available: true` for all) until the
// database stage adds a real calendar.
export const rooms: Room[] = [
  {
    id: "1",
    slug: "the-atrium-suite",
    name: "The Atrium Suite",
    type: "Deluxe",
    location: "Ughelli North, Delta State",
    shortDescription:
      "A marble-floored suite with a dedicated lounge area and smart TV wall.",
    description:
      "The Atrium Suite pairs a plush king bed with a private sitting area, finished in polished marble and warm wood paneling. It's built for guests who want hotel comfort with the extra breathing room of a small lounge — ideal for a short business trip or a weekend away.",
    pricePerNight: 85000,
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    bedInfo: "1 King bed",
    amenities: [
      "Free Wi-Fi",
      "Air conditioning",
      "55\" Smart TV",
      "Private sitting area",
      "Hot water",
      "Room service",
    ],
    houseRules: [
      "Check-in from 2:00 PM, check-out by 12:00 PM",
      "No smoking inside the room",
      "Visitors must be signed in at the front desk",
      "Valid ID required at check-in",
    ],
    checkInTime: "2:00 PM",
    checkOutTime: "12:00 PM",
    available: true,
    image: "/brand/room-1.jpg",
    gallery: ["/brand/room-1.jpg"],
  },
  {
    id: "2",
    slug: "skyline-two-bed-apartment",
    name: "Skyline Two-Bed Apartment",
    type: "Apartment",
    location: "Ughelli North, Delta State",
    shortDescription:
      "A two-bedroom short-let apartment with a full kitchen, for longer stays.",
    description:
      "A self-contained two-bedroom apartment for guests staying longer or travelling as a group. Comes with a kitchenette, backup power, and secure parking, so you can live comfortably rather than just sleep over.",
    pricePerNight: 140000,
    maxGuests: 4,
    bedrooms: 2,
    bathrooms: 2,
    bedInfo: "2 Queen beds",
    amenities: [
      "Free Wi-Fi",
      "Kitchenette",
      "Generator backup",
      "Private parking",
      "Air conditioning",
      "Room service",
    ],
    houseRules: [
      "Check-in from 2:00 PM, check-out by 12:00 PM",
      "No smoking inside the apartment",
      "Maximum 4 guests, no exceptions",
      "Valid ID required at check-in",
    ],
    checkInTime: "2:00 PM",
    checkOutTime: "12:00 PM",
    available: true,
    image: "/brand/room-2.jpg",
    gallery: ["/brand/room-2.jpg"],
  },
  {
    id: "3",
    slug: "garden-loft-room",
    name: "Garden Loft Room",
    type: "Standard",
    location: "Ughelli North, Delta State",
    shortDescription:
      "A cosy, well-priced room with breakfast included — good for a short stay.",
    description:
      "A compact, comfortable room for guests who mostly need a clean, well-serviced base for the night. Breakfast is included, and the room looks out over the courtyard garden.",
    pricePerNight: 65000,
    maxGuests: 2,
    bedrooms: 1,
    bathrooms: 1,
    bedInfo: "1 Queen bed",
    amenities: [
      "Free Wi-Fi",
      "Air conditioning",
      "Breakfast included",
      "Hot water",
    ],
    houseRules: [
      "Check-in from 2:00 PM, check-out by 12:00 PM",
      "No smoking inside the room",
      "Valid ID required at check-in",
    ],
    checkInTime: "2:00 PM",
    checkOutTime: "12:00 PM",
    available: true,
    image:
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?q=80&w=1400&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?q=80&w=1400&auto=format&fit=crop",
    ],
  },
  {
    id: "4",
    slug: "the-penthouse",
    name: "The Penthouse",
    type: "Suite",
    location: "Ughelli North, Delta State",
    shortDescription:
      "Our top-floor suite with a private terrace and jacuzzi, for a special stay.",
    description:
      "The Penthouse is Hotel De' Papi's flagship room: three bedrooms, a private terrace, and a jacuzzi, for guests who want the best room in the building. Suited to a special occasion or hosting a small group in real comfort.",
    pricePerNight: 250000,
    maxGuests: 6,
    bedrooms: 3,
    bathrooms: 3,
    bedInfo: "1 King bed, 2 Queen beds",
    amenities: [
      "Free Wi-Fi",
      "Private terrace",
      "Jacuzzi",
      "Butler service",
      "Air conditioning",
      "55\" Smart TV",
    ],
    houseRules: [
      "Check-in from 2:00 PM, check-out by 12:00 PM",
      "No smoking inside the suite",
      "Maximum 6 guests, no exceptions",
      "Valid ID required at check-in",
    ],
    checkInTime: "2:00 PM",
    checkOutTime: "12:00 PM",
    available: true,
    image:
      "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?q=80&w=1400&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?q=80&w=1400&auto=format&fit=crop",
    ],
  },
];

export function getRoomBySlug(slug: string): Room | undefined {
  return rooms.find((room) => room.slug === slug);
}

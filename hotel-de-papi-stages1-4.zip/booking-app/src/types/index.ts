export type RoomType = "Standard" | "Deluxe" | "Suite" | "Apartment";

export type Room = {
  id: string;
  slug: string;
  name: string;
  type: RoomType;
  location: string;
  shortDescription: string;
  description: string;
  pricePerNight: number; // in naira, whole number
  maxGuests: number;
  bedrooms: number;
  bathrooms: number;
  bedInfo: string;
  amenities: string[];
  houseRules: string[];
  checkInTime: string;
  checkOutTime: string;
  available: boolean;
  image: string;
  gallery: string[];
};

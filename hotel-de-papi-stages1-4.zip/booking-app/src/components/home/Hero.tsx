import Image from "next/image";
import Link from "next/link";
import SearchBar from "./SearchBar";

export default function Hero() {
  return (
    <div className="relative">
      <div className="relative h-[92vh] min-h-[640px] w-full overflow-hidden">
        <Image
          src="/brand/exterior.jpg"
          alt="Hotel De' Papi entrance and courtyard, Ughelli North, Delta State"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/20 to-ink/55" />

        <div className="relative z-10 mx-auto flex h-full max-w-content flex-col justify-center px-6 md:px-10">
          <p className="mb-4 text-sm font-medium uppercase tracking-[0.2em] text-gold-bright">
            Ughelli North, Delta State
          </p>
          <h1 className="max-w-xl font-display text-4xl leading-[1.1] text-sand md:text-6xl">
            Stay by daylight.
            <br />
            Stay out all night.
          </h1>
          <p className="mt-5 max-w-md text-base text-sand/85 md:text-lg">
            Hotel rooms and short-let apartments for your trip, and a VIP
            lounge for the night you don&apos;t want to end.
          </p>

          <Link
            href="/#stays"
            className="mt-8 inline-flex w-fit items-center gap-2 rounded-full bg-gold-bright px-8 py-4 text-base font-semibold text-ink shadow-[0_15px_40px_-10px_rgba(185,134,63,0.6)] transition hover:bg-sand"
          >
            Book your room
          </Link>
        </div>
      </div>

      <div className="px-6 md:px-10">
        <SearchBar />
      </div>
    </div>
  );
}

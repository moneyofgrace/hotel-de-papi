"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Users, Search } from "lucide-react";

export default function SearchBar() {
  const router = useRouter();
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState(2);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (checkIn) params.set("checkIn", checkIn);
    if (checkOut) params.set("checkOut", checkOut);
    if (guests) params.set("guests", String(guests));
    router.push(`/rooms?${params.toString()}`);
  }

  return (
    <form
      className="relative z-20 mx-auto -mt-10 flex w-full max-w-content flex-col gap-3 rounded-2xl bg-sand p-4 shadow-[0_20px_60px_-15px_rgba(18,21,27,0.35)] md:-mt-14 md:flex-row md:items-center md:gap-0 md:rounded-full md:p-2"
      onSubmit={handleSubmit}
    >
      <div className="flex flex-1 flex-col gap-1 px-4 py-2 md:border-r md:border-ink/10">
        <label className="text-xs font-medium uppercase tracking-wide text-ink/50">
          Check-in
        </label>
        <input
          type="date"
          value={checkIn}
          onChange={(e) => setCheckIn(e.target.value)}
          className="bg-transparent text-sm text-ink outline-none [color-scheme:light]"
        />
      </div>

      <div className="flex flex-1 flex-col gap-1 px-4 py-2 md:border-r md:border-ink/10">
        <label className="text-xs font-medium uppercase tracking-wide text-ink/50">
          Check-out
        </label>
        <input
          type="date"
          value={checkOut}
          onChange={(e) => setCheckOut(e.target.value)}
          className="bg-transparent text-sm text-ink outline-none [color-scheme:light]"
        />
      </div>

      <div className="flex flex-1 flex-col gap-1 px-4 py-2">
        <label className="text-xs font-medium uppercase tracking-wide text-ink/50">
          Guests
        </label>
        <div className="flex items-center gap-2">
          <Users size={16} className="text-ink/50" />
          <input
            type="number"
            min={1}
            max={12}
            value={guests}
            onChange={(e) => setGuests(Number(e.target.value))}
            className="w-12 bg-transparent text-sm text-ink outline-none"
          />
        </div>
      </div>

      <button
        type="submit"
        className="flex items-center justify-center gap-2 rounded-full bg-gold-bright px-7 py-4 text-sm font-semibold text-ink shadow-md transition hover:bg-ink hover:text-sand md:ml-2"
      >
        <Search size={16} />
        Search availability
      </button>
    </form>
  );
}

import Image from "next/image";
import Link from "next/link";
import { BedDouble, Bath, Users } from "lucide-react";
import { Room } from "@/types";

function formatNaira(amount: number) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(amount);
}

export default function RoomCard({ room }: { room: Room }) {
  return (
    <div className="group flex flex-col">
      <Link
        href={`/rooms/${room.slug}`}
        className="relative block aspect-[4/3] w-full overflow-hidden rounded-2xl"
      >
        <Image
          src={room.image}
          alt={room.name}
          fill
          className="object-cover transition duration-500 group-hover:scale-105"
        />
      </Link>

      <div className="flex flex-1 flex-col gap-2 pt-5">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-display text-xl text-ink">{room.name}</h3>
          <p className="whitespace-nowrap text-sm font-medium text-ink">
            {formatNaira(room.pricePerNight)}
            <span className="text-ink/50"> / night</span>
          </p>
        </div>

        <p className="text-sm text-ink/60">{room.location}</p>

        <div className="mt-1 flex items-center gap-4 text-ink/60">
          <span className="flex items-center gap-1 text-xs">
            <Users size={14} /> {room.maxGuests} guests
          </span>
          <span className="flex items-center gap-1 text-xs">
            <BedDouble size={14} /> {room.bedrooms}
          </span>
          <span className="flex items-center gap-1 text-xs">
            <Bath size={14} /> {room.bathrooms}
          </span>
        </div>

        <div className="mt-2 flex flex-wrap gap-2">
          {room.amenities.slice(0, 3).map((item) => (
            <span
              key={item}
              className="rounded-full border border-gold/30 px-2.5 py-1 text-[11px] text-ink/70"
            >
              {item}
            </span>
          ))}
        </div>

        <Link
          href={`/rooms/${room.slug}#book`}
          className="mt-4 inline-flex w-fit items-center rounded-full bg-ink px-6 py-2.5 text-sm font-semibold text-sand transition group-hover:bg-gold-bright group-hover:text-ink"
        >
          Book now
        </Link>
      </div>
    </div>
  );
}

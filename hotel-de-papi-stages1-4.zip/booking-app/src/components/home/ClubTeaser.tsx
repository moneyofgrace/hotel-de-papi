import Image from "next/image";
import Link from "next/link";

export default function ClubTeaser() {
  return (
    <section className="bg-ink px-6 py-20 md:px-10">
      <div className="mx-auto grid max-w-content grid-cols-1 items-center gap-10 md:grid-cols-2">
        <div>
          <p className="mb-2 text-sm font-medium uppercase tracking-[0.2em] text-gold-bright">
            After dark
          </p>
          <h2 className="font-display text-3xl text-sand md:text-4xl">
            The club upstairs
          </h2>
          <p className="mt-4 max-w-md text-sand/70">
            Live sets, guest DJs, and VIP tables every weekend. Reserve a
            table for your crew before the good ones are gone.
          </p>
          <Link
            href="/club"
            className="mt-6 inline-block rounded-full bg-gold px-6 py-3 text-sm font-medium text-ink transition hover:bg-gold-bright"
          >
            See upcoming events
          </Link>
        </div>

        <div className="relative aspect-[4/3] overflow-hidden rounded-2xl">
          <Image
            src="https://images.unsplash.com/photo-1571266028243-d220c9c3b31d?q=80&w=1400&auto=format&fit=crop"
            alt="VIP table area at the Hotel De' Papi club"
            fill
            className="object-cover"
          />
        </div>
      </div>
    </section>
  );
}

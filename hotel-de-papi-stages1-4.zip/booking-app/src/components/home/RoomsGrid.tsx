import Link from "next/link";
import { rooms } from "@/lib/data/rooms";
import RoomCard from "./RoomCard";

export default function RoomsGrid() {
  return (
    <section id="stays" className="mx-auto max-w-content px-6 py-20 md:px-10">
      <div className="mb-10 flex items-end justify-between">
        <div>
          <p className="mb-2 text-sm font-medium uppercase tracking-[0.2em] text-gold">
            Available now
          </p>
          <h2 className="font-display text-3xl italic text-ink md:text-4xl">
            Rooms &amp; apartments
          </h2>
        </div>
        <Link
          href="/rooms"
          className="hidden text-sm font-medium text-ink underline decoration-gold underline-offset-4 sm:inline"
        >
          View all rooms
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-x-10 gap-y-16 md:grid-cols-2 lg:grid-cols-3">
        {rooms.map((room) => (
          <RoomCard key={room.id} room={room} />
        ))}
      </div>

      <Link
        href="/rooms"
        className="mt-10 flex items-center justify-center rounded-full border border-ink/15 py-3 text-sm font-medium text-ink sm:hidden"
      >
        View all rooms
      </Link>
    </section>
  );
}

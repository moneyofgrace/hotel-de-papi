import Link from "next/link";
import { Phone, MessageCircle } from "lucide-react";

const ADDRESS =
  "14 Eric Oharisi Street, Slaughter Road, Otowodo, Ughelli North, Delta State, Nigeria";

// No real contact number has been provided yet. These stay unset rather
// than showing a fake number — set them in .env once you have the real
// WhatsApp and front-desk numbers, and the buttons below will appear.
const WHATSAPP_NUMBER = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "2348151123462";
const PHONE_NUMBER = process.env.NEXT_PUBLIC_PHONE_NUMBER ?? "";
const MAPS_EMBED_URL =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_EMBED_URL ||
  `https://www.google.com/maps?q=${encodeURIComponent(ADDRESS)}&output=embed`;

export default function Footer() {
  return (
    <footer id="contact" className="bg-ink px-6 py-16 md:px-10">
      <div className="mx-auto grid max-w-content grid-cols-1 gap-12 md:grid-cols-2">
        <div>
          <h3 className="font-display text-2xl text-sand">
            Visit or reach us
          </h3>
          <p className="mt-3 max-w-sm text-sand/60">
            {ADDRESS}. Front desk open 24 hours for guests and reservations.
          </p>

          {(WHATSAPP_NUMBER || PHONE_NUMBER) && (
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              {WHATSAPP_NUMBER && (
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 rounded-full bg-gold px-5 py-3 text-sm font-medium text-sand transition hover:bg-gold-bright hover:text-ink"
                >
                  <MessageCircle size={16} />
                  Chat on WhatsApp
                </a>
              )}
              {PHONE_NUMBER && (
                <a
                  href={`tel:${PHONE_NUMBER}`}
                  className="flex items-center justify-center gap-2 rounded-full border border-sand/25 px-5 py-3 text-sm font-medium text-sand transition hover:bg-sand/10"
                >
                  <Phone size={16} />
                  {PHONE_NUMBER}
                </a>
              )}
            </div>
          )}

          <p className="mt-10 text-xs text-sand/40">
            © {new Date().getFullYear()} Hotel De' Papi. All rights reserved.
          </p>
        </div>

        <div className="overflow-hidden rounded-2xl">
          <iframe
            src={MAPS_EMBED_URL}
            width="100%"
            height="260"
            style={{ border: 0 }}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Hotel De' Papi location"
          />
        </div>
      </div>

      <div className="mt-10 flex justify-center gap-6 text-xs text-sand/40">
        <Link href="/club" className="hover:text-sand/70">
          Club &amp; Events
        </Link>
        <Link href="/admin" className="hover:text-sand/70">
          Staff login
        </Link>
      </div>
    </footer>
  );
}

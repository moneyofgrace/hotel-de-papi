import Link from "next/link";
import Image from "next/image";
import { Menu } from "lucide-react";

export default function Navbar() {
  return (
    <header className="absolute top-0 left-0 right-0 z-30">
      <nav className="mx-auto flex max-w-content items-center justify-between px-6 py-5 md:px-10">
        <Link href="/" className="flex items-center gap-3">
          <Image
            src="/brand/logo.jpg"
            alt="Hotel De' Papi"
            width={52}
            height={52}
            className="h-11 w-11 rounded-full object-cover md:h-[52px] md:w-[52px]"
            priority
          />
          <span className="hidden font-display text-lg uppercase tracking-wide text-sand sm:inline">
            Hotel De&apos; Papi
          </span>
        </Link>

        <div className="hidden items-center gap-8 text-sm text-sand/90 md:flex">
          <Link href="/rooms" className="hover:text-gold-bright">
            Stays
          </Link>
          <Link href="/club" className="hover:text-gold-bright">
            Club &amp; Events
          </Link>
          <Link href="/#contact" className="hover:text-gold-bright">
            Contact
          </Link>
        </div>

        <div className="flex items-center gap-4">
          <Link
            href="/rooms"
            className="hidden rounded-full bg-gold-bright px-6 py-3 text-sm font-semibold text-ink shadow-md transition hover:bg-sand md:inline-block"
          >
            Book now
          </Link>
          <button
            aria-label="Open menu"
            className="text-sand md:hidden"
          >
            <Menu size={26} />
          </button>
        </div>
      </nav>
    </header>
  );
}

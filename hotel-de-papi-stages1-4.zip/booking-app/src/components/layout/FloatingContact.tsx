import { MessageCircle, Phone } from "lucide-react";

// Unset until the real numbers are added to .env — see Footer.tsx note.
const WHATSAPP_NUMBER = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "2348151123462";
const PHONE_NUMBER = process.env.NEXT_PUBLIC_PHONE_NUMBER ?? "";

export default function FloatingContact() {
  if (!WHATSAPP_NUMBER && !PHONE_NUMBER) return null;

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col gap-3">
      {PHONE_NUMBER && (
        <a
          href={`tel:${PHONE_NUMBER}`}
          aria-label="Call us"
          className="flex h-12 w-12 items-center justify-center rounded-full bg-ink text-sand shadow-lg transition hover:bg-ink-soft"
        >
          <Phone size={20} />
        </a>
      )}
      {WHATSAPP_NUMBER && (
        <a
          href={`https://wa.me/${WHATSAPP_NUMBER}`}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat on WhatsApp"
          className="flex h-12 w-12 items-center justify-center rounded-full bg-gold text-sand shadow-lg transition hover:bg-gold-bright hover:text-ink"
        >
          <MessageCircle size={20} />
        </a>
      )}
    </div>
  );
}

import Image from "next/image";
import Link from "next/link";
import { BedDouble, Bath, Users } from "lucide-react";
import { Room } from "@/types";
import { formatNaira } from "@/lib/booking";

export default function RoomListingCard({ room }: { room: Room }) {
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl bg-white/40 md:flex-row">
      <div className="relative h-64 w-full flex-shrink-0 md:h-auto md:w-80">
        <Image
          src={room.image}
          alt={room.name}
          fill
          className="object-cover"
        />
        <span
          className={`absolute left-3 top-3 rounded-full px-3 py-1 text-[11px] font-semibold ${
            room.available
              ? "bg-ink text-sand"
              : "bg-sand text-ink/60"
          }`}
        >
          {room.available ? "Available now" : "Fully booked"}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-5 md:p-6">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <span className="text-xs font-medium uppercase tracking-wide text-gold">
              {room.type}
            </span>
            <h3 className="font-display text-xl text-ink">{room.name}</h3>
          </div>
          <p className="whitespace-nowrap text-right text-sm font-medium text-ink">
            {formatNaira(room.pricePerNight)}
            <span className="block text-xs font-normal text-ink/50">
              per night
            </span>
          </p>
        </div>

        <p className="text-sm text-ink/70">{room.shortDescription}</p>

        <div className="flex items-center gap-4 text-ink/60">
          <span className="flex items-center gap-1 text-xs">
            <Users size={14} /> {room.maxGuests} guests
          </span>
          <span className="flex items-center gap-1 text-xs">
            <BedDouble size={14} /> {room.bedrooms} bed
            {room.bedrooms > 1 ? "s" : ""}
          </span>
          <span className="flex items-center gap-1 text-xs">
            <Bath size={14} /> {room.bathrooms} bath
            {room.bathrooms > 1 ? "s" : ""}
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {room.amenities.slice(0, 4).map((item) => (
            <span
              key={item}
              className="rounded-full border border-gold/30 px-2.5 py-1 text-[11px] text-ink/70"
            >
              {item}
            </span>
          ))}
        </div>

        <div className="mt-auto flex flex-wrap gap-3 pt-2">
          <Link
            href={`/rooms/${room.slug}`}
            className="rounded-full border border-ink/20 px-5 py-2.5 text-sm font-medium text-ink transition hover:border-ink/50"
          >
            View details
          </Link>
          <Link
            href={`/rooms/${room.slug}#book`}
            className="rounded-full bg-gold-bright px-5 py-2.5 text-sm font-semibold text-ink transition hover:bg-ink hover:text-sand"
          >
            Book now
          </Link>
        </div>
      </div>
    </div>
  );
}

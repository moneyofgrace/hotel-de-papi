"use client";

import { RoomType } from "@/types";

const TYPES: Array<RoomType | "All"> = [
  "All",
  "Standard",
  "Deluxe",
  "Suite",
  "Apartment",
];

export default function RoomTypeFilter({
  active,
  onChange,
}: {
  active: RoomType | "All";
  onChange: (type: RoomType | "All") => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {TYPES.map((type) => (
        <button
          key={type}
          onClick={() => onChange(type)}
          className={`rounded-full border px-4 py-2 text-sm font-medium transition ${
            active === type
              ? "border-ink bg-ink text-sand"
              : "border-ink/15 bg-transparent text-ink/70 hover:border-ink/40"
          }`}
        >
          {type}
        </button>
      ))}
    </div>
  );
}

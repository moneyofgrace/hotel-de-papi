"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Room } from "@/types";
import { formatNaira, nightsBetween, generateBookingReference } from "@/lib/booking";

export default function BookingForm({ room }: { room: Room }) {
  const router = useRouter();
  const today = new Date().toISOString().split("T")[0];

  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState(2);
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");

  const nights = useMemo(() => nightsBetween(checkIn, checkOut), [checkIn, checkOut]);
  const total = nights * room.pricePerNight;

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (!checkIn || !checkOut) {
      setError("Please select a check-in and check-out date.");
      return;
    }
    if (nights <= 0) {
      setError("Check-out must be after check-in.");
      return;
    }
    if (guests < 1 || guests > room.maxGuests) {
      setError(`This room fits up to ${room.maxGuests} guests.`);
      return;
    }
    if (!fullName.trim() || !phone.trim()) {
      setError("Please add your name and phone number.");
      return;
    }
    if (!room.available) {
      setError("This room isn't available to book right now.");
      return;
    }

    const reference = generateBookingReference();
    const params = new URLSearchParams({
      ref: reference,
      type: "Room booking",
      room: room.name,
      checkIn,
      checkOut,
      nights: String(nights),
      guests: String(guests),
      total: String(total),
      name: fullName.trim(),
      phone: phone.trim(),
    });

    router.push(`/booking/confirmation?${params.toString()}`);
  }

  return (
    <form
      id="book"
      onSubmit={handleSubmit}
      className="scroll-mt-28 rounded-2xl bg-white/50 p-6 md:p-8"
    >
      <h3 className="font-display text-2xl text-ink">Book this room</h3>
      <p className="mt-1 text-sm text-ink/60">
        {formatNaira(room.pricePerNight)}{" "}
        <span className="text-ink/50">/ night</span> · Check-in{" "}
        {room.checkInTime}, check-out {room.checkOutTime}
      </p>

      <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium uppercase tracking-wide text-ink/50">
            Check-in
          </label>
          <input
            type="date"
            min={today}
            value={checkIn}
            onChange={(e) => setCheckIn(e.target.value)}
            className="rounded-lg border border-ink/15 bg-sand px-3 py-2.5 text-sm text-ink outline-none [color-scheme:light]"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium uppercase tracking-wide text-ink/50">
            Check-out
          </label>
          <input
            type="date"
            min={checkIn || today}
            value={checkOut}
            onChange={(e) => setCheckOut(e.target.value)}
            className="rounded-lg border border-ink/15 bg-sand px-3 py-2.5 text-sm text-ink outline-none [color-scheme:light]"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium uppercase tracking-wide text-ink/50">
            Guests (max {room.maxGuests})
          </label>
          <input
            type="number"
            min={1}
            max={room.maxGuests}
            value={guests}
            onChange={(e) => setGuests(Number(e.target.value))}
            className="rounded-lg border border-ink/15 bg-sand px-3 py-2.5 text-sm text-ink outline-none"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium uppercase tracking-wide text-ink/50">
            Full name
          </label>
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="As it appears on your ID"
            className="rounded-lg border border-ink/15 bg-sand px-3 py-2.5 text-sm text-ink outline-none placeholder:text-ink/30"
          />
        </div>
        <div className="flex flex-col gap-1 sm:col-span-2">
          <label className="text-xs font-medium uppercase tracking-wide text-ink/50">
            Phone number
          </label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="e.g. 0815 112 3462"
            className="rounded-lg border border-ink/15 bg-sand px-3 py-2.5 text-sm text-ink outline-none placeholder:text-ink/30"
          />
        </div>
      </div>

      {nights > 0 && (
        <div className="mt-5 flex items-center justify-between border-t border-ink/10 pt-4 text-sm">
          <span className="text-ink/60">
            {formatNaira(room.pricePerNight)} × {nights} night
            {nights > 1 ? "s" : ""}
          </span>
          <span className="font-display text-xl text-ink">
            {formatNaira(total)}
          </span>
        </div>
      )}

      {error && (
        <p className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </p>
      )}

      <button
        type="submit"
        className="mt-5 w-full rounded-full bg-gold-bright px-6 py-3.5 text-sm font-semibold text-ink transition hover:bg-ink hover:text-sand sm:w-auto"
      >
        Book now
      </button>

      <p className="mt-3 text-xs text-ink/40">
        This confirms your request instantly for now — it isn&apos;t checked
        against a live calendar yet. That's coming in the database stage, so
        please still expect a confirmation call from the front desk.
      </p>
    </form>
  );
}
